// ── CART MANAGEMENT ──
let cart = JSON.parse(localStorage.getItem("sweetbite_cart")) || [];

function saveCart() {
  localStorage.setItem("sweetbite_cart", JSON.stringify(cart));
  updateCartBadge();
}

function updateCartBadge() {
  const badges = document.querySelectorAll(".cart-badge");
  const total = cart.reduce((sum, item) => sum + item.qty, 0);
  badges.forEach(b => {
    b.textContent = total;
    b.style.display = total > 0 ? "flex" : "none";
  });
}

// quantity per food card (in-page, not cart)
const quantities = {};

function getQty(id) {
  return quantities[id] || 1;
}

function changeQty(id, delta) {
  quantities[id] = Math.max(1, (quantities[id] || 1) + delta);
  const el = document.getElementById("qty-" + id);
  if (el) el.textContent = quantities[id];
}

function addCart(name, price, img, id) {
  const qty = getQty(id || name);
  const existing = cart.find(i => i.name === name);
  if (existing) {
    existing.qty += qty;
  } else {
    cart.push({ name, price, img: img || "", qty });
  }
  saveCart();

  // button feedback
  const btn = document.getElementById("btn-" + (id || name));
  if (btn) {
    btn.classList.add("added");
    btn.innerHTML = "✓ Added";
    setTimeout(() => {
      btn.classList.remove("added");
      btn.innerHTML = `<span>🛒</span> Add to Cart`;
    }, 1500);
  }

  showToast(`${qty} × ${name} added to cart! 🎉`);
}

function showToast(msg) {
  let toast = document.getElementById("toast");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "toast";
    toast.className = "toast";
    document.body.appendChild(toast);
  }
  toast.innerHTML = `<span class="toast-icon">🍽️</span><span>${msg}</span>`;
  toast.classList.add("show");
  clearTimeout(window._toastTimer);
  window._toastTimer = setTimeout(() => toast.classList.remove("show"), 2800);
}

// ── CART PAGE ──
function loadCart() {
  const container = document.getElementById("cartItems");
  if (!container) return;

  if (cart.length === 0) {
    container.innerHTML = `
      <div class="empty-cart">
        <div class="empty-icon">🛒</div>
        <h3>Your cart is empty</h3>
        <p>Looks like you haven't added anything yet.</p>
        <a href="menu.html" class="btn-primary" style="text-decoration:none;display:inline-flex;">Browse Menu</a>
      </div>`;
    document.querySelector(".order-summary")?.style && (document.querySelector(".order-summary").style.display = "none");
    return;
  }

  container.innerHTML = "";
  cart.forEach((item, idx) => {
    const div = document.createElement("div");
    div.className = "cart-item";
    div.innerHTML = `
      <img class="cart-item-img" src="${item.img || 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=200&q=70'}" alt="${item.name}">
      <div class="cart-item-info">
        <div class="cart-item-name">${item.name}</div>
        <div class="cart-item-price">Rs.${item.price} each</div>
        <div class="qty-ctrl" style="margin-top:8px;display:inline-flex">
          <button class="qty-btn" onclick="changeCartQty(${idx}, -1)">−</button>
          <span class="qty-num" id="cart-qty-${idx}">${item.qty}</span>
          <button class="qty-btn" onclick="changeCartQty(${idx}, 1)">+</button>
        </div>
      </div>
      <div class="cart-item-right">
        <div class="cart-item-total">Rs.${(item.price * item.qty).toFixed(2)}</div>
        <button class="cart-remove" onclick="removeItem(${idx})">✕ Remove</button>
      </div>`;
    container.appendChild(div);
  });

  updateSummary();
}

function changeCartQty(idx, delta) {
  cart[idx].qty = Math.max(1, cart[idx].qty + delta);
  document.getElementById("cart-qty-" + idx).textContent = cart[idx].qty;
  saveCart();
  updateSummary();
  // update total for this item
  const totals = document.querySelectorAll(".cart-item-total");
  if (totals[idx]) totals[idx].textContent = `Rs.${(cart[idx].price * cart[idx].qty).toFixed(2)}`;
}

function removeItem(idx) {
  cart.splice(idx, 1);
  saveCart();
  loadCart();
}

function updateSummary() {
  const subtotal = cart.reduce((sum, i) => sum + i.price * i.qty, 0);
  const delivery = subtotal > 0 ? 2.99 : 0;
  const tax = subtotal * 0.08;
  const total = subtotal + delivery + tax;

  const s = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
  s("summary-subtotal", `Rs.${subtotal.toFixed(2)}`);
  s("summary-delivery", delivery > 0 ? `Rs.${delivery.toFixed(2)}` : "Free");
  s("summary-tax", `Rs.${tax.toFixed(2)}`);
  s("summary-total", `Rs.${total.toFixed(2)}`);
  s("item-count", cart.reduce((sum, i) => sum + i.qty, 0));
}

function checkout() {
  if (cart.length === 0) { showToast("Your cart is empty!"); return; }
  document.getElementById("cartItems").innerHTML = `
    <div class="empty-cart">
      <div class="empty-icon">🎉</div>
      <h3>Order Placed Successfully!</h3>
      <p>Your delicious food is being prepared and will arrive shortly.</p>
      <a href="menu.html" class="btn-primary" style="text-decoration:none;display:inline-flex;margin-top:8px">Order More</a>
    </div>`;
  document.querySelector(".order-summary").style.display = "none";
  cart = [];
  saveCart();
}

// ── SEARCH ──
function initSearch() {
  const input = document.getElementById("search");
  if (!input) return;
  input.addEventListener("input", () => {
    const q = input.value.toLowerCase();
    document.querySelectorAll(".food-card").forEach(card => {
      const name = card.querySelector(".food-name")?.textContent.toLowerCase() || "";
      card.style.display = name.includes(q) ? "" : "none";
    });
  });
}

// ── FILTER TABS ──
function initFilters() {
  document.querySelectorAll(".filter-tab").forEach(tab => {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".filter-tab").forEach(t => t.classList.remove("active"));
      tab.classList.add("active");
      const filter = tab.dataset.filter;
      document.querySelectorAll(".food-card").forEach(card => {
        card.style.display = (filter === "all" || card.dataset.category === filter) ? "" : "none";
      });
    });
  });
}

// ── MOBILE NAV ──
function initNav() {
  const hamburger = document.querySelector(".hamburger");
  const navLinks = document.querySelector(".nav-links");
  if (hamburger && navLinks) {
    hamburger.addEventListener("click", () => navLinks.classList.toggle("open"));
  }
}

// ── INIT ──
document.addEventListener("DOMContentLoaded", () => {
  updateCartBadge();
  loadCart();
  initSearch();
  initFilters();
  initNav();
});